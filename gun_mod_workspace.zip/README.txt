havn't opened another persons work? just double click on the MCreator logo, if nothing pops up install MCreator.

keep the exe in the same folder with the src and elements.